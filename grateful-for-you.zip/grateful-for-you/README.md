# The world is grateful for you

Thanksgiving Day blessing cards — hand-painted, cut apart, and written on by hand.

A quiet interactive page: draw a card, turn it over, or browse them all.  
Also includes a printable sheet (six cards to a page, double-sided).

## Files

- `index.html` — the site
- `images/` — the painted cards and wreath
- `the-world-is-grateful-for-you.pdf` — printable sheet

## Hosting on GitHub Pages

1. Create a new repository (public is fine).
2. Upload everything in this folder (keep the structure).
3. Go to **Settings → Pages** and set the source to the `main` branch / root.
4. Your site will be live at `https://YOURUSERNAME.github.io/REPO-NAME/`

Works in any browser — no special tools required. The PDF downloads normally.

---

Made by Carolyn Dawn Good / C.D. Good Media Art  
[The story of the cards on Patreon](https://www.patreon.com/CDGood/posts/176393336)
